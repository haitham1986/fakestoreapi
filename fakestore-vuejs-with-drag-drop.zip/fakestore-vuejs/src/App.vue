<script setup>
import Header from './components/Header.vue'
import Footer from './components/Footer.vue'
import Orders from "@/components/Orders.vue";
import Modal from "@/components/Modal.vue";
</script>

<template>
  <Header/>
  <Modal />
  <Orders/>
  <Footer/>
</template>

<style scoped>

</style>
