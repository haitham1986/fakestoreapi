<script setup>
</script>

<template>
  <footer class="navbar-dark bg-dark text-center text-white p-4">
    <div class="container">
      <p class="mb-0">Copyrights Platzi Fake Store API</p>
    </div>
  </footer>
</template>

<style scoped>

</style>