<script>
import * as bootstrap from 'bootstrap';
window.bootstrap = bootstrap;
export default {
  name: "modal",
  data() {
    return {
      expanded: false
    };
  },
  methods:{
    hideModal(el) {
      new bootstrap.Modal('.bd-example-modal-lg', {}).hide();
    }
  }
};
</script>

<template>
  <div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
       aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">New message</h5>
          <button type="button" class="close" data-dismiss="bd-example-modal-lg" aria-label="Close" @click="hideModal($event.target)">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body" id="main-modal-content">
          <div class="row">
            <div class="col-md-6">
              <img src="" class="modal-image">
            </div>
            <div class="col-md-6">
              <h4 class="modal-title mt-5">name</h4>
              <hr>
              <h5 class="modal-price">price</h5>
              <strong>Category:</strong>
              <p class="modal-category">category</p>
              <strong>Rate:</strong>
              <p class="modal-rating">rating</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>

</style>