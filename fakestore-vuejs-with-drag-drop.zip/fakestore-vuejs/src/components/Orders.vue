<script setup>
import Product from "@/components/Product.vue";
import draggable from 'vuedraggable'
import {ref} from "vue";
import * as bootstrap from "bootstrap";
import $ from "jquery";

const products = ref(null);
fetch('https://fakestoreapi.com/products')
    .then(response => response.json())
    .then(data => products.value = data);
function showModal(el) {
  let product_id = el.getAttribute('data-id');
  let category= el.getAttribute('data-category');
  let rating= el.getAttribute('data-rating');
  let image= el.getAttribute('data-image');
  let title= el.getAttribute('data-title');
  let price= el.getAttribute('data-price');
  new bootstrap.Modal('.bd-example-modal-lg', {}).show();
  // $('.bd-example-modal-lg').modal('show');
  $('.modal-title').html(title);
  $('.modal-category').html(category);
  $('.modal-rating').html(rating);
  $('.modal-price').html('$'+price);
  $('.modal-image').attr('src',image);
}
</script>

<template>
  <div class="main-products-content">
    <div class="container">
      <h2 class="text-center my-5">User Orders</h2>
<!--      <div class="row" id="main-products-loop">-->
<!--        <product v-for="(item, index) in products" :item="item" :index="index" :key="item.id"/>-->
        <draggable :list="products" tag="div" item-key="id" class="row" id="main-products-loop">
          <template #item="{element : item}">
            <div class="col-md-3 product-card" :data-sort="id">
              <div class="card text-center mb-3">
                <img :src="item.image" class="card-img-top" :alt="item.title">
                <div class="card-body">
                  <h6 class="card-title">{{ item.title }}</h6>
                  <h5 class="price">${{ item.price }}</h5>
                  <a href="#" class="btn btn-primary product-show-details"
                     :data-category="item.category"
                     :data-rating="item.rating.rate"
                     :data-image="item.image"
                     :data-title="item.title"
                     :data-price="item.price"
                     :data-id="item.title" data-toggle="modal"
                     data-target=".bd-example-modal-lg"
                     @click.prevent="showModal($event.target)">Details</a>
                </div>
              </div>
            </div>
          </template>
        </draggable>
<!--      </div>-->
    </div>
  </div>
</template>

<style scoped>

</style>