<script>
import $ from "jquery";
import * as bootstrap from 'bootstrap';
window.bootstrap = bootstrap;
export default {
  name: "product",
  props: ["index","item"],
  data() {
    return {
      expanded: false
    };
  },
  methods:{
    showModal(el) {
      let product_id = el.getAttribute('data-id');
      let category= el.getAttribute('data-category');
      let rating= el.getAttribute('data-rating');
      let image= el.getAttribute('data-image');
      let title= el.getAttribute('data-title');
      let price= el.getAttribute('data-price');
      new bootstrap.Modal('.bd-example-modal-lg', {}).show();
      // $('.bd-example-modal-lg').modal('show');
      $('.modal-title').html(title);
      $('.modal-category').html(category);
      $('.modal-rating').html(rating);
      $('.modal-price').html('$'+price);
      $('.modal-image').attr('src',image);
    }
  }
};
</script>

<template>
  <div class="col-md-3 product-card" :data-sort="index">
    <div class="card text-center mb-3">
      <img :src="item.image" class="card-img-top" :alt="item.title">
      <div class="card-body">
        <h6 class="card-title">{{ item.title }}</h6>
        <h5 class="price">${{ item.price }}</h5>
        <a href="#" class="btn btn-primary product-show-details"
           :data-category="item.category"
           :data-rating="item.rating.rate"
           :data-image="item.image"
           :data-title="item.title"
           :data-price="item.price"
           :data-id="item.title" data-toggle="modal"
           data-target=".bd-example-modal-lg"
          @click.prevent="showModal($event.target)">Details</a>
      </div>
    </div>
  </div>
</template>

<style scoped>

</style>